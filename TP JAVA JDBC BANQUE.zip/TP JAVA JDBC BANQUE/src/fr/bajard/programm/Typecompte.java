package fr.bajard.programm;


// par Isa
public class Typecompte {
	private int code;
	private String intitule;
	
	public Typecompte(int code, String intitule) {
		super();
		this.code = code;
		this.intitule = intitule;
		
	}
	
	public Typecompte() {
	}
	

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getIntitule() {
		return intitule;
	}

	public void setIntitule(String intitule) {
		this.intitule = intitule;
	}

	@Override
	public String toString() {
		return "typecompte [code=" + code + ", intitule=" + intitule + "]";
	}
	
	
	
}
