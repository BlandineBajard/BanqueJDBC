package fr.bajard.programm;

// par H�di

public class Compte {
	private int numero;
	private int codeTypeCompte;
	private int codeTitulaire;
	private float solde;
	private Titulaire titulaire;
	
	
	public Compte(int numero, int codeTypeCompte, int codeTitulaire, float solde, Titulaire titulaire) {
		super();
		this.numero = numero;
		this.codeTypeCompte = codeTypeCompte;
		this.codeTitulaire = codeTitulaire;
		this.solde = solde;
		this.titulaire= titulaire;
	}

	public Compte() {
	}

	
	public Titulaire getTitulaire() {
		return titulaire;
	}

	public void setTitulaire(Titulaire titulaire) {
		this.titulaire = titulaire;
	}

	public int getNumero() {
		return numero;
	}


	public void setNumero(int numero) {
		this.numero = numero;
	}


	public int getCodeTypeCompte() {
		return codeTypeCompte;
	}


	public void setCodeTypeCompte(int codeTypeCompte) {
		this.codeTypeCompte = codeTypeCompte;
	}


	public int getCodeTitulaire() {
		return codeTitulaire;
	}


	public void setCodeTitulaire(int codeTitulaire) {
		this.codeTitulaire = codeTitulaire;
	}


	public float getSolde() {
		return solde;
	}


	public void setSolde(float solde) {
		this.solde = solde;
	}

	
	//Blandine
	public void afficherListeComptesTitulaire() {
		System.out.println(titulaire.getNom()+" "+ titulaire.getPrenom()+" / Num�ro Client : " +titulaire.getCode()+" / Num�ro de Compte : " + numero);
	}
	

	@Override
	public String toString() {
		return "Compte [numero=" + numero + ", codeTypeCompte=" + codeTypeCompte + ", codeTitulaire=" + codeTitulaire
				+ ", solde=" + solde + " "+titulaire.getNom()+"]";
	}

	
	

	
}