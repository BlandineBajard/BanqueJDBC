package fr.bajard.programm;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;


import fr.bajard.connexion.AccesBD;


public class Requetes {
	

//Blandine = READ pour "compte"	
public static ArrayList<Compte> getAllComptes() throws SQLException{
	
	ArrayList<Compte> comptes = new ArrayList<Compte>();
	String requete = "SELECT * FROM compte";
	ResultSet resultat = AccesBD.executerQuery(requete);
	
	while(resultat.next()) {
		Compte compte = new Compte();
		compte.setNumero(resultat.getInt("numero"));
		compte.setCodeTypeCompte(resultat.getInt("codeTypeCompte"));
		compte.setCodeTitulaire(resultat.getInt("codeTitulaire"));
		compte.setSolde(resultat.getFloat("solde"));
		compte.setTitulaire(Requetes.getTitulaireByCode(resultat.getInt("codeTitulaire")));
		comptes.add(compte);
	}
	
	return comptes;
	
}
// Vincent = READ pour "type de compte"
public static ArrayList<Typecompte> getAllTypecompte() throws SQLException, ClassNotFoundException{
	
	ArrayList<Typecompte> typecomptes = new ArrayList<Typecompte>();
	String requette = " Select * FROM typecompte ";
	ResultSet resultat = AccesBD.executerQuery(requette);
	
	while(resultat.next()) {
		Typecompte typecompte=new Typecompte();
		typecompte.setCode(resultat.getInt("code"));
		typecompte.setIntitule(resultat.getString("intitule"));
		typecomptes.add(typecompte);
	}
	
	return typecomptes;
}

// H�di = READ pour titulaire
public static ArrayList<Titulaire> getAllTitulaires() throws SQLException{
	ArrayList<Titulaire> titulaires = new ArrayList<Titulaire>();
	String requete = "SELECT * FROM titulaire";
	ResultSet resultat = AccesBD.executerQuery(requete);
	
	while(resultat.next()) {
		Titulaire titulaire = new Titulaire();
		titulaire.setCode(resultat.getInt("code"));
		titulaire.setPrenom(resultat.getString("prenom"));
		titulaire.setNom(resultat.getString("nom"));
		titulaire.setAdresse(resultat.getString("adresse"));
		titulaire.setCodePostal(resultat.getString("codePostal"));
		titulaires.add(titulaire);
	}
	return titulaires;

}


// Blandine = CUD pour "Compte"

public static void ajouterCompte(Compte compte) throws SQLException {
	PreparedStatement PreparedStatement = AccesBD.getConnection().prepareStatement("insert into compte values (? , ? , ? , ?)");
	PreparedStatement.setInt(1, compte.getNumero());
	PreparedStatement.setInt(2, compte.getCodeTypeCompte());
	PreparedStatement.setInt(3, compte.getCodeTitulaire());
	PreparedStatement.setFloat(4, compte.getSolde());

    PreparedStatement.executeUpdate();
}

public static void supprimerCompte(int numero) throws SQLException {
	PreparedStatement PreparedStatement = AccesBD.getConnection().prepareStatement("delete from compte where numero=?");
	PreparedStatement.setInt(1, numero);
	
	PreparedStatement.executeUpdate();
	
}
public static void  modifierCompte(int numero, float solde) throws SQLException{
    PreparedStatement PreparedStatement = AccesBD.getConnection().prepareStatement("update compte set solde=? where numero=?");
    PreparedStatement.setFloat(1, solde);
    PreparedStatement.setInt(2, numero);

    PreparedStatement.executeUpdate();		
}

// Isa  = CreateUpdate pour "Type de compte"
public static void AjouterTypecompte(Typecompte typecompte ) throws SQLException {
	
	 AccesBD.executerUpdate("INSERT INTO typecompte (code,intitule) VALUES ("+typecompte.getCode()+",\""+typecompte.getIntitule()+"\")");
      
}

public static void modifierTypeCompte (Typecompte typecompte) throws SQLException {
	AccesBD.executerUpdate("update typecompte set intitule='"+typecompte.getIntitule() +"' where code="+typecompte.getCode());
}

// Vincent = Delete pour "Type de compte"
public static void supprimerTypecompte(int code) throws SQLException {
    AccesBD.executerUpdate("delete from typecompte where code="+code);
}

// H�di = CUD pour "titulaire"
public static void  ajouterTitulaire(Titulaire titulaire) throws SQLException
{
    PreparedStatement PreparedStatement = AccesBD.getConnection().prepareStatement("INSERT INTO titulaire VALUES (? , ? , ? , ? , ?)");
    PreparedStatement.setInt(1, titulaire.getCode());
    PreparedStatement.setString(2, titulaire.getPrenom());
    PreparedStatement.setString(3, titulaire.getNom());
    PreparedStatement.setString(4, titulaire.getAdresse());
    PreparedStatement.setString(5, titulaire.getCodePostal());
    PreparedStatement.executeUpdate();
}	

public static void  modifierTitulaire(Titulaire titulaire) throws SQLException{
    PreparedStatement PreparedStatement = AccesBD.getConnection().prepareStatement("UPDATE titulaire SET prenom = ?, nom = ? , adresse = ? , codePostal = ? WHERE code = ?");
    PreparedStatement.setInt(5, titulaire.getCode());
    PreparedStatement.setString(1, titulaire.getPrenom());
    PreparedStatement.setString(2, titulaire.getNom());
    PreparedStatement.setString(3, titulaire.getAdresse());
    PreparedStatement.setString(4, titulaire.getCodePostal());
    PreparedStatement.executeUpdate();		
}	

public static void supprimerTitulaire(Titulaire titulaire) throws SQLException{
    PreparedStatement PreparedStatement = AccesBD.getConnection().prepareStatement("DELETE FROM titulaire WHERE code = ?");
    PreparedStatement.setInt(1, titulaire.getCode());
    PreparedStatement.executeUpdate();		
}
// par H�di
public static Titulaire getTitulaireByCode(int code) throws SQLException {
	Titulaire titulaire = new Titulaire();
	String requete = "SELECT * FROM titulaire where code="+code;
	ResultSet resultat = AccesBD.executerQuery(requete);
	resultat.next();
	
	titulaire.setCode(resultat.getInt("code"));
	titulaire.setNom(resultat.getString("nom"));
	titulaire.setPrenom(resultat.getString("prenom"));
	
	return titulaire;
	
}
// par H�di
public static ArrayList<Operations> getAllOperationsByNumeroCompte(int numeroCompte) throws SQLException{
	ArrayList<Operations> operations = new ArrayList<Operations>();
	String requete = "SELECT * FROM operations left join compte on operations.numeroCompte = compte.numero left join typecompte on typecompte.code = compte.codeTypeCompte where operations.numeroCompte="+numeroCompte;
	ResultSet resultat = AccesBD.executerQuery(requete);
	
	while(resultat.next()) {
		Operations operation = new Operations();
		operation.setNumero(resultat.getInt("numero"));
		operation.setNumeroCompte(resultat.getInt("numeroCompte"));
		operation.setDate(resultat.getDate("date"));
		operation.setLibelle(resultat.getString("libelle"));
		operation.setMontant(resultat.getFloat("montant"));
		operation.setTypeop(resultat.getString("typeop"));
		operation.setCompte(Requetes.getCompteByNumero(resultat.getInt("numeroCompte")));
		operation.setTypecompte(Requetes.getTypecompteByCode(resultat.getInt("codeTypeCompte")));
		operations.add(operation);
	}
	return operations;
}	

public static Compte getCompteByNumero(int numero) throws SQLException {
    Compte compte = new Compte();
    String requete = "SELECT * FROM compte where numero="+numero;
    ResultSet resultat = AccesBD.executerQuery(requete);
    resultat.next();
    
    compte.setNumero(resultat.getInt("numero"));
    compte.setCodeTypeCompte(resultat.getInt("codeTypeCompte"));
    compte.setCodeTitulaire(resultat.getInt("codeTitulaire"));
    compte.setSolde(resultat.getFloat("solde"));

    return compte;

}

public static Typecompte getTypecompteByCode(int code) throws SQLException {
    Typecompte typecompte = new Typecompte();
    String requete = "SELECT * FROM typecompte where code="+code;
    ResultSet resultat = AccesBD.executerQuery(requete);
    resultat.next();
    
    typecompte.setCode(resultat.getInt("code"));
    typecompte.setIntitule(resultat.getString("intitule"));

    return typecompte;

}
//Afficher la liste des comptes d'un m�me titulaire // par Blandine et Vincent
public static ArrayList<Compte> getComptesTitulaire(int code) throws SQLException{
	
	ArrayList<Compte> comptes = new ArrayList<Compte>();
	String requete = "select prenom, nom ,numero, codeTitulaire from titulaire,compte where code=codeTitulaire and code="+code;
	ResultSet resultat = AccesBD.executerQuery(requete);
	
	while(resultat.next()) {
		Compte compte = new Compte();
		compte.setNumero(resultat.getInt("numero"));
		compte.setTitulaire(Requetes.getTitulaireByCode(resultat.getInt("codeTitulaire")));
		comptes.add(compte);
		
	}
	return comptes;
	
}

// par Vincent = ajouter une op�ration retrait ou depot
public static void ajouterOperations(Operations operation) throws SQLException 
{
    PreparedStatement PreparedStatement = AccesBD.getConnection().prepareStatement("insert into operations values (?, ?, ?, ?, ?, ?)");
    PreparedStatement.setInt(1,operation.getNumero());
    PreparedStatement.setInt(2,operation.getNumeroCompte());
    PreparedStatement.setDate(3,operation.getDate());
    PreparedStatement.setString(4,operation.getLibelle());
    PreparedStatement.setFloat(5,operation.getMontant());
    PreparedStatement.setString(6,operation.getTypeop());
    PreparedStatement.executeUpdate();

}

//par Vincent et Blandine = mettre � jour le solde d'un compte apr�s une op�ration
public static void miseAJourSolde(Operations operation) throws SQLException {
	AccesBD.executerUpdate("update compte inner join operations on operations.numeroCompte = compte.numero set solde = solde+"+operation.getMontant() + " where compte.numero="+operation.getNumeroCompte());
	
}
// par H�di et Isa = effectuer un virement bancaire
public static void virementsBancaire(int emetteur,int destinataire, float montant) throws SQLException {
	float soldeEmetteur = Requetes.getCompteByNumero(emetteur).getSolde();
	float soldeDestinataire = Requetes.getCompteByNumero(destinataire).getSolde();
	
	if(soldeEmetteur-montant < 0) {
		System.out.println("Virement impossible");
		return;
	}
	
	float nouveauSoldeEmetteur = soldeEmetteur-montant;
	Requetes.modifierCompte (emetteur, nouveauSoldeEmetteur);

	
	float nouveauSoldeDestinataire = soldeDestinataire+montant;
	Requetes.modifierCompte (destinataire, nouveauSoldeDestinataire);
	
	Operations operationEmetteur = new Operations();
	operationEmetteur.setNumeroCompte(emetteur);
	operationEmetteur.setDate(Date.valueOf("2021-10-18"));
	operationEmetteur.setLibelle("virement pour "+getTitulaireByCode(getCompteByNumero(destinataire).getCodeTitulaire()).getNom());
	operationEmetteur.setMontant(montant);
	operationEmetteur.setTypeop("-");
	ajouterOperations(operationEmetteur);

	Operations operationDestinataire = new Operations();
	operationDestinataire.setNumeroCompte(destinataire);
	operationDestinataire.setDate(Date.valueOf("2021-10-18"));
	operationDestinataire.setLibelle("virement de "+getTitulaireByCode(getCompteByNumero(emetteur).getCodeTitulaire()).getNom());
	operationDestinataire.setMontant(montant);
	operationDestinataire.setTypeop("-");
	ajouterOperations(operationDestinataire);
	
	System.out.println("Virement ok");
	
}


// methode main pour affichage et ex�cution = par H�di, Vincent, Isabelle & Blandine

public static void main(String[]args) throws SQLException, java.lang.ClassNotFoundException {
	
	
	// Appel des methodes pour "comptes" :
	
	//ajouterCompte(new Compte(12349,1,1004,(float) 200.00));
	//modifierCompte(12345, (float) 450.34);
	//supprimerCompte(12346);
	
	//Appel des methodes pour "titulaire" :
	
	//ajouterTitulaire();
	//modifierTitulaire();
	//supprimerTitulaire();
	
	// Appel des methodes pour "type de compte" :
	
	//ajouterTypecompte(new Typecompte(0,"Livret A"));
	//modifierTypeCompte (new Typecompte(8,"Livret B"));
	//supprimerTypecompte(8);
	
	//Appel des methodes pour effectuer des op�rations
	
	//ajouterOperations(new Operations(0,10001, Date.valueOf("2021-10-18"),"Test2",(float)100.00, "+", null, null));
	//supprimerOperations(new Operations(0,10001, Date.valueOf("2021-10-18"),"Test3",(float)100.00, "-", null, null));
	
	//Appel des methodes pour mise � jour du solde du compte suite � une op�ration de d�p�t ou de retrait
	
	//miseAJourSolde(new Operations(0,10005, Date.valueOf("2021-10-21"), "Test4", (float)100.00, "+", null, null));
	
	//Appel de la m�thode pour effectuer un virement bancaire et mettre � jour le solde des titulaires
	
	//virementsBancaire(10002,10001,500);
	
	// Affichage des requ�tes
	
	for (Compte compte : Requetes.getAllComptes()) {                      // affichage de Comptes
	System.out.println(compte);
}
	for (Compte compte : Requetes.getComptesTitulaire(1002)) {			// affichage des comptes d'un titulaire
	compte.afficherListeComptesTitulaire();
}

	for (Typecompte typecompte : Requetes.getAllTypecompte()) {				// affichage des types de comptes
	System.out.println(typecompte);
}
	for (Titulaire titulaire : Requetes.getAllTitulaires()) {				// affichage des titulaires
	System.out.println(titulaire);
}
	
	for (Operations operation : Requetes.getAllOperationsByNumeroCompte(10001)) { //affichage de toutes les op�rations sur un compte
	System.out.println(operation);
}

	
}
}
