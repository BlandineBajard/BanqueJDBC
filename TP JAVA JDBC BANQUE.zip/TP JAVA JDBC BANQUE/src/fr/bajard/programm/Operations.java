package fr.bajard.programm;

import java.sql.Date;

// par Blandine
public class Operations {

	private int numero;
	private int numeroCompte;
	private Date date;
	private String libelle;
	private float montant;
	private String typeop;
	private Compte compte;
	private Typecompte typecompte;
	
	public Operations(int numero, int numeroCompte, Date date, String libelle, float montant, String typeop, Compte compte, Typecompte typecompte) {
		super();
		this.numero = numero;
		this.numeroCompte = numeroCompte;
		this.date = date;
		this.libelle = libelle;
		this.montant = montant;
		this.typeop = typeop;
		this.compte = compte;
		this.typecompte = typecompte;
	}
	
	public Operations() {
		
	}
	
	

	public Compte getCompte() {
		return compte;
	}

	public void setCompte(Compte compte) {
		this.compte = compte;
	}

	public Typecompte getTypecompte() {
		return typecompte;
	}

	public void setTypecompte(Typecompte typecompte) {
		this.typecompte = typecompte;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getNumeroCompte() {
		return numeroCompte;
	}

	public void setNumeroCompte(int numeroCompte) {
		this.numeroCompte = numeroCompte;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public float getMontant() {
		return montant;
	}

	public void setMontant(float montant) {
		this.montant = montant;
	}

	public String getTypeop() {
		return typeop;
	}

	public void setTypeop(String typeop) {
		this.typeop = typeop;
	}

	@Override
	public String toString() {
		return "Operations [numero=" + numero + ", numeroCompte=" + numeroCompte + ", date=" + date + ", libelle="
				+ libelle + ", montant=" + montant + ", typeop=" + typeop +", Solde=" + compte.getSolde() + ", TypeCompte="+ typecompte.getIntitule() +"]";
	}
	
	
	
}
