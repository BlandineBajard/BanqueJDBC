package fr.bajard.programm;

// par Vincent
public class Titulaire {
	
	private int code;
	private String  prenom;
	private String nom;
	private String adresse;
	private String CodePostal;
	
	public Titulaire(int code, String prenom, String nom, String adresse, String CodePostal) {
		
		this.code = code;
		this.prenom = prenom;
		this.nom = nom;
		this.adresse = adresse;
		this.CodePostal = CodePostal;
	}
	
	public Titulaire() {
		
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public String getCodePostal() {
		return CodePostal;
	}

	public void setCodePostal(String codePostal) {
		CodePostal = codePostal;
	}

	@Override
	public String toString() {
		return "titulaire [code=" + code + ", prenom=" + prenom + ", nom=" + nom + ", adresse=" + adresse
				+ ", CodePostal=" + CodePostal + "]";
	}
	
	

}
